#!/usr/bin/env bash
CNAME="mimo-v26-flash-sglang"
echo "=== 容器状态 ==="; docker ps -a --format "{{.Names}}  {{.Status}}" | grep "$CNAME" || echo "无容器"
echo "=== ModelScope 缓存大小 ==="; du -sh /root/.cache/modelscope 2>/dev/null || echo "无缓存"
echo "=== SGLang 日志(尾部) ==="; docker logs --tail 15 "$CNAME" 2>&1 || true
echo "=== 健康检查 ==="; curl -sS -m 5 http://localhost:30000/v1/models 2>&1 | head -c 400 || echo "尚未就绪"
