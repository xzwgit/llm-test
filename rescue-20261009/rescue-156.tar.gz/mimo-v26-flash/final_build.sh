#!/bin/bash
set -u
LOG=/tmp/final_build.log
NEWIMG=mimo-sglang:main2
echo "[$(date)] 起临时容器升级 kernel" | tee -a $LOG
CID=$(docker run -d --entrypoint sleep mimo-sglang:main 999999)
docker exec -d "$CID" bash -c "pip install -U sglang-kernel > /tmp/k.log 2>&1; echo DONE >> /tmp/k.log"
OK=0
for i in $(seq 1 60); do
  sleep 15
  V=$(docker exec "$CID" python -c "import sglang_kernel; print(sglang_kernel.__version__)" 2>/dev/null)
  echo "[$(date)] kernel=$V" | tee -a $LOG
  if [ "$V" != "0.4.7" ] && [ -n "$V" ]; then OK=1; break; fi
done
if [ $OK -ne 1 ]; then echo "[$(date)] kernel 升级失败" | tee -a $LOG; docker logs "$CID" 2>&1 | tail; docker rm -f "$CID"; exit 1; fi
echo "[$(date)] kernel=$V, commit $NEWIMG" | tee -a $LOG
docker commit "$CID" "$NEWIMG" 2>&1 | tee -a $LOG
docker rm -f "$CID" 2>/dev/null

MODEL="/root/.cache/modelscope/models/XiaomiMiMo/MiMo-V2.6-Flash-RL"
MS_CACHE="/root/.cache/modelscope"
docker rm -f mimo-main-test 2>/dev/null || true
echo "[$(date)] 起推理(tp8 attn-dp2)..." | tee -a $LOG
docker run -d --name mimo-main-test --entrypoint sglang \
  --gpus all --ipc=host --shm-size=32g --cap-add SYS_NICE \
  -p 30002:30000 \
  -e MODELSCOPE_CACHE="$MS_CACHE" -e SGLANG_USE_MODELSCOPE=True \
  -e HF_HUB_OFFLINE=1 -e TRANSFORMERS_OFFLINE=1 -e MODELSCOPE_OFFLINE=1 -e PYTHONUNBUFFERED=1 \
  -v "$MS_CACHE:$MS_CACHE" \
  "$NEWIMG" \
  serve --trust-remote-code --model-path "$MODEL" --tp 8 --attn-dp-size 2 --disable-cuda-graph --host 0.0.0.0 --port 30000 2>&1 | tee -a $LOG
echo "[$(date)] 等待服务..." | tee -a $LOG
READY=0
for i in $(seq 1 40); do
  sleep 15
  if curl -sS --max-time 5 http://127.0.0.1:30002/health >/dev/null 2>&1; then READY=1; echo "[$(date)] up" | tee -a $LOG; break; fi
done
if [ $READY -ne 1 ]; then echo "[$(date)] 未起, 末日志:" | tee -a $LOG; docker logs --tail 35 mimo-main-test 2>&1 | tee -a $LOG; exit 1; fi
echo "[$(date)] 发推理..." | tee -a $LOG
curl -sS --max-time 220 http://127.0.0.1:30002/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d "{\"model\":\"$MODEL\",\"messages\":[{\"role\":\"user\",\"content\":\"用一句话介绍你自己\"}],\"temperature\":1.0,\"top_p\":0.95,\"max_tokens\":256,\"enable_thinking\":true,\"stream\":false}" \
  > /tmp/main_min_out.json 2>> $LOG
echo "[$(date)] 输出:" | tee -a $LOG
cat /tmp/main_min_out.json | tee -a $LOG
