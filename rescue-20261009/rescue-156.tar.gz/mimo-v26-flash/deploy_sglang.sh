#!/usr/bin/env bash
# 用 SGLang 部署 MiMo-V2.6-Flash-RL (8x RTX PRO 6000), 模型来自 ModelScope
# 官方 README 主推 SGLang, 对 FA3/sink 支持更好
set -e
MODEL="/root/.cache/modelscope/models/XiaomiMiMo/MiMo-V2.6-Flash-RL"
IMAGE="lmsysorg/sglang:latest"
HOST_PORT=30000
CONTAINER_NAME="mimo-v26-flash-sglang"
MS_CACHE="/root/.cache/modelscope"

if ! docker image inspect "$IMAGE" >/dev/null 2>&1; then
  echo "拉取镜像 $IMAGE ..."
  docker pull "$IMAGE"
fi
docker rm -f "$CONTAINER_NAME" 2>/dev/null || true

docker run -d --name "$CONTAINER_NAME" \
  --gpus all --ipc=host --shm-size=32g --cap-add SYS_NICE \
  -p ${HOST_PORT}:30000 \
  -e MODELSCOPE_CACHE="${MS_CACHE}" \
  -e PYTHONUNBUFFERED=1 \
  -e SGLANG_USE_MODELSCOPE=True \
  -e HF_HUB_OFFLINE=1 \
  -e TRANSFORMERS_OFFLINE=1 \
  -e MODELSCOPE_OFFLINE=1 \
  -v "${MS_CACHE}:${MS_CACHE}" \
  "$IMAGE" \
  sglang serve \
  --trust-remote-code \
  --model-path "$MODEL" \
  --tp 8 \
  --dp 2 \
  --enable-dp-attention \
  --enable-dp-lm-head \
  --mm-enable-dp-encoder \
  --mem-fraction-static 0.65 \
  --chunked-prefill-size 16384 \
  --speculative-algorithm EAGLE \
  --speculative-num-steps 3 \
  --speculative-eagle-topk 1 \
  --speculative-num-draft-tokens 4 \
  --enable-multi-layer-eagle \
  --reasoning-parser mimo \
  --tool-call-parser mimo \
  --log-level debug --disable-cuda-graph --host 0.0.0.0 \
  --port 30000

echo "容器 $CONTAINER_NAME 已启动, 端口 $HOST_PORT"
