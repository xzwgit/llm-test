#!/bin/bash
set -u
LOG=/tmp/build_main_test.log
SRC=/root/mimo-v26-flash/sglang_src/python/sglang
NEWIMG=mimo-sglang:main
echo "[$(date)] 重新构建测试(修正 entrypoint)" | tee -a $LOG

MODEL="/root/.cache/modelscope/models/XiaomiMiMo/MiMo-V2.6-Flash-RL"
MS_CACHE="/root/.cache/modelscope"
docker rm -f mimo-main-test 2>/dev/null || true
echo "[$(date)] 起最小推理容器 (tp8, 端口30002, entrypoint=sglang)..." | tee -a $LOG
docker run -d --name mimo-main-test --entrypoint sglang \
  --gpus all --ipc=host --shm-size=32g --cap-add SYS_NICE \
  -p 30002:30000 \
  -e MODELSCOPE_CACHE="$MS_CACHE" -e SGLANG_USE_MODELSCOPE=True \
  -e HF_HUB_OFFLINE=1 -e TRANSFORMERS_OFFLINE=1 -e MODELSCOPE_OFFLINE=1 -e PYTHONUNBUFFERED=1 \
  -v "$MS_CACHE:$MS_CACHE" \
  "$NEWIMG" \
  serve --trust-remote-code --model-path "$MODEL" --tp 8 --attn-dp-size 2 --disable-cuda-graph --host 0.0.0.0 --port 30000 2>&1 | tee -a $LOG

echo "[$(date)] 等待服务(最多10分钟)..." | tee -a $LOG
READY=0
for i in $(seq 1 40); do
  sleep 15
  if curl -sS --max-time 5 http://127.0.0.1:30002/health >/dev/null 2>&1; then READY=1; echo "[$(date)] up" | tee -a $LOG; break; fi
done
if [ $READY -ne 1 ]; then echo "[$(date)] 未起来, 末日志:" | tee -a $LOG; docker logs --tail 30 mimo-main-test 2>&1 | tee -a $LOG; exit 1; fi

echo "[$(date)] 发推理请求..." | tee -a $LOG
curl -sS --max-time 200 http://127.0.0.1:30002/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d "{\"model\":\"$MODEL\",\"messages\":[{\"role\":\"user\",\"content\":\"用一句话介绍你自己\"}],\"temperature\":1.0,\"top_p\":0.95,\"max_tokens\":256,\"enable_thinking\":true,\"stream\":false}" \
  > /tmp/main_min_out.json 2>> $LOG
echo "[$(date)] 推理输出:" | tee -a $LOG
cat /tmp/main_min_out.json | tee -a $LOG
