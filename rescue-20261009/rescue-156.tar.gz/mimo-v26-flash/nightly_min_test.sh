#!/bin/bash
set -e
LOG=/tmp/nightly_min_test.log
echo "[$(date)] 等待 nightly 拉取完成..." | tee -a $LOG
while ! grep -q PULL_DONE /root/mimo-v26-flash/pull_nightly.log 2>/dev/null; do
  sleep 15
done
echo "[$(date)] nightly 拉取完成, 开始最小 MoE 验证" | tee -a $LOG

MODEL="/root/.cache/modelscope/models/XiaomiMiMo/MiMo-V2.6-Flash-RL"
MS_CACHE="/root/.cache/modelscope"
docker rm -f mimo-nightly-test 2>/dev/null || true

docker run -d --name mimo-nightly-test \
  --gpus all --ipc=host --shm-size=32g --cap-add SYS_NICE \
  -p 30001:30000 \
  -e MODELSCOPE_CACHE="$MS_CACHE" \
  -e SGLANG_USE_MODELSCOPE=True \
  -e HF_HUB_OFFLINE=1 -e TRANSFORMERS_OFFLINE=1 -e MODELSCOPE_OFFLINE=1 \
  -e PYTHONUNBUFFERED=1 \
  -v "$MS_CACHE:$MS_CACHE" \
  lmsysorg/sglang:nightly \
  sglang serve --trust-remote-code --model-path "$MODEL" \
  --tp 8 --disable-cuda-graph --host 0.0.0.0 --port 30000 2>&1 | tee -a $LOG

echo "[$(date)] 等待服务起来(最多8分钟)..." | tee -a $LOG
READY=0
for i in $(seq 1 32); do
  sleep 15
  if curl -sS --max-time 5 http://127.0.0.1:30001/health >/dev/null 2>&1; then
    echo "[$(date)] 服务 up (第$i次检查)" | tee -a $LOG
    READY=1
    break
  fi
done
if [ $READY -ne 1 ]; then
  echo "[$(date)] 服务未起来, 最后日志:" | tee -a $LOG
  docker logs --tail 30 mimo-nightly-test 2>&1 | tee -a $LOG
  exit 1
fi

echo "[$(date)] 发最小推理请求..." | tee -a $LOG
curl -sS --max-time 180 http://127.0.0.1:30001/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d "{\"model\":\"$MODEL\",\"messages\":[{\"role\":\"user\",\"content\":\"用一句话介绍你自己\"}],\"temperature\":1.0,\"top_p\":0.95,\"max_tokens\":256,\"enable_thinking\":true,\"stream\":false}" \
  > /tmp/nightly_min_out.json 2>> $LOG
echo "[$(date)] 推理结果:" | tee -a $LOG
cat /tmp/nightly_min_out.json | tee -a $LOG
