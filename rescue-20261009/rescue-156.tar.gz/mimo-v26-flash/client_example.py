#!/usr/bin/env python3
import os
from openai import OpenAI
BASE_URL = os.environ.get("MIMO_BASE_URL", "http://localhost:8000/v1")
API_KEY  = os.environ.get("MIMO_API_KEY", "EMPTY")
MODEL    = os.environ.get("MIMO_MODEL", "mimo-v2.6-flash-rl")
client = OpenAI(base_url=BASE_URL, api_key=API_KEY)
resp = client.chat.completions.create(
    model=MODEL,
    messages=[{"role": "user", "content": "15% of 240 是多少? 请逐步思考。"}],
    max_tokens=2048, temperature=1.0, top_p=0.95,
    extra_body={"chat_template_kwargs": {"enable_thinking": True}},
)
msg = resp.choices[0].message
print("=== 思考过程 ==="); print(getattr(msg, "reasoning_content", "") or "(无)")
print("\n=== 回答 ==="); print(msg.content or "")
