#!/bin/bash
# Production deployment for MiMo-V2.6-Flash-RL on 8x RTX PRO 6000 (Blackwell)
# mimo-sglang:fixed3 = SGLang main + sglang-kernel 0.4.9 + torch 2.14.1 + torchvision 0.29.1+cu130
# Critical flags: --moe-runner-backend flashinfer_mxfp4 (Blackwell SM100 MXFP4 MoE)
#                 --mm-enable-dp-encoder (vision attention with attn-dp-size 2)
# EAGLE speculative currently disabled (fails to init with mxfp4+dp; core serve verified).
set -e
MODEL=/root/.cache/modelscope/models/XiaomiMiMo/MiMo-V2.6-Flash-RL
docker run -d \
  --name mimo-prod \
  --entrypoint sglang \
  --gpus all \
  --ipc=host --shm-size=32g --cap-add SYS_NICE \
  -p 30000:30000 \
  -e MODELSCOPE_CACHE=/root/.cache/modelscope \
  -e SGLANG_USE_MODELSCOPE=True \
  -e HF_HUB_OFFLINE=1 -e TRANSFORMERS_OFFLINE=1 -e MODELSCOPE_OFFLINE=1 \
  -e PYTHONUNBUFFERED=1 \
  -v /root/.cache/modelscope:/root/.cache/modelscope \
  mimo-sglang:fixed3 serve \
  --trust-remote-code \
  --model-path "$MODEL" \
  --tp 8 --dp 2 --enable-dp-attention --enable-dp-lm-head --mm-enable-dp-encoder \
  --moe-runner-backend flashinfer_mxfp4 \
  --mem-fraction-static 0.65 \
  --chunked-prefill-size 16384 \
  --reasoning-parser mimo --tool-call-parser mimo \
  --host 0.0.0.0 --port 30000
echo "mimo-prod launch issued"
