#!/usr/bin/env bash
#
# build_mimo_image.sh
# ---------------------------------------------------------------------------
# Reproducible build of the SGLang image that can serve MiMo-V2.6-Flash-RL
# on 8x RTX PRO 6000 (Blackwell, sm_120) with MXFP4 MoE.
#
# Result image: mimo-sglang:fixed3   (or $OUT_TAG if overridden)
#
# WHY THIS EXACT RECIPE (hard-won, do not "simplify"):
#   * Base lmsysorg/sglang:latest == 0.5.21 lacks Blackwell MXFP4 MoE support.
#   * We overlay SGLang MAIN source (has the mxfp4_flashinfer_trtllm path) and
#     sglang-kernel==0.4.9 (provides the SM100 kernels).
#   * sglang-kernel 0.4.9 REQUIRES torch==2.14.1 (its .so references
#     CUDAErrorLogCapture). torch 2.13.x breaks it.
#   * torch 2.14.1 + torchvision 0.28.0/cu130 breaks `import torchvision`
#     (RuntimeError: operator torchvision::nms does not exist).
#   * The working pair is: torch 2.14.1 + torchvision 0.29.1+cu130.
#     torchvision must come from the cu130 index to match torch's build.
#
# Network note (server 10.10.3.156):
#   Docker Hub registry-1.docker.io is UNREACHABLE, but PyPI, the cu130 wheel
#   index, GitHub raw, and modelscope.cn are reachable. The base image
#   lmsysorg/sglang:latest must therefore already be present locally
#   (it was imported once). If missing, copy it from a machine that has it.
#
# Usage:
#   ./build_mimo_image.sh            # builds mimo-sglang:fixed3
#   OUT_TAG=mimo-sglang:repro ./build_mimo_image.sh
# ---------------------------------------------------------------------------
set -euo pipefail

OUT_TAG="${OUT_TAG:-mimo-sglang:fixed3}"
BASE_IMG="${BASE_IMG:-lmsysorg/sglang:latest}"
WORKDIR="${WORKDIR:-/root/mimo-v26-flash}"
SG_MAIN_DIR="${SG_MAIN_DIR:-$WORKDIR/sglang_src/python/sglang}"
# Pin SGLang main to the commit known-good for Blackwell MXFP4 MoE.
# (git clone --depth 1 of latest main later broke serving; pin it.)
SG_COMMIT="${SG_COMMIT:-e00930c5489053f26d86b179cee0d087f846acbb}"
TORCH_VER="${TORCH_VER:-2.14.1}"
TV_VER="${TV_VER:-0.29.1+cu130}"
KERNEL_VER="${KERNEL_VER:-0.4.9}"

echo "==> Building $OUT_TAG"
echo "    base=$BASE_IMG  torch=$TORCH_VER  torchvision=$TV_VER  sglang-kernel=$KERNEL_VER"

# --- Preconditions -------------------------------------------------------
command -v docker >/dev/null || { echo "ERROR: docker not found"; exit 1; }
docker image inspect "$BASE_IMG" >/dev/null 2>&1 || {
  echo "ERROR: base image $BASE_IMG not present locally.";
  echo "       Import it from a host that can reach Docker Hub, then rerun.";
  exit 1;
}
if [ ! -d "$SG_MAIN_DIR/.git" ]; then
  echo "==> SGLang main source not found at $SG_MAIN_DIR"
  echo "    Cloning (needs GitHub reachability)..."
  mkdir -p "$(dirname "$SG_MAIN_DIR")"
  rm -rf "$(dirname "$SG_MAIN_DIR")/sglang"
  git clone https://github.com/sgl-project/sglang.git "$(dirname "$SG_MAIN_DIR")/sglang"
fi
# Pin to the known-good commit (latest main later broke MXFP4 serving).
echo "==> Checking out pinned SGLang commit $SG_COMMIT"
git -C "$(dirname "$SG_MAIN_DIR")/sglang" checkout -q "$SG_COMMIT" 2>&1 | tail -2 || {
  echo "ERROR: could not checkout $SG_COMMIT (need 'git fetch' if shallow)."; exit 1;
}
# The package root we overlay must be .../python/sglang (not sglang/srt).
[ -f "$SG_MAIN_DIR/__init__.py" ] || {
  echo "ERROR: $SG_MAIN_DIR does not look like the sglang python package (no __init__.py)";
  exit 1;
}

# --- Write the Dockerfile ------------------------------------------------
DOCKERFILE="$WORKDIR/Dockerfile.mimo"
cat > "$DOCKERFILE" <<EOF
FROM $BASE_IMG
USER root

# 1) Overlay SGLang MAIN source over the 0.5.21 install.
COPY sglang_src/python/sglang /tmp/sglang_main
RUN cd /sgl-workspace/sglang/python && rm -rf sglang && cp -r /tmp/sglang_main sglang

# 2) Install the MXFP4-capable kernel (pulls torch 2.14.1 as a dependency).
RUN pip install -U "sglang-kernel==$KERNEL_VER" 2>&1 | tail -3

# 3) Pin the torch/torchvision pair that actually works on Blackwell.
#    - torch from default PyPI (cu130 index for torch 2.14.1 is very slow/unreachable here)
#    - torchvision from the cu130 index to match torch 2.14.1's build,
#      otherwise "operator torchvision::nms does not exist" at import time.
RUN pip install --no-deps "torch==$TORCH_VER" 2>&1 | tail -3
RUN pip install --no-deps "torchvision==$TV_VER" \\
    --index-url https://download.pytorch.org/whl/cu130 2>&1 | tail -3

# 4) (No import self-check here: torchvision nms self-registers only at
#    runtime with libcuda present; the running server is the real test.)
EOF

echo "==> Dockerfile written to $DOCKERFILE"

# --- Build ---------------------------------------------------------------
cd "$WORKDIR"
# context must include sglang_src so COPY works
docker build -f "$DOCKERFILE" -t "$OUT_TAG" . 2>&1 | tail -40

echo "==> Done. Image $OUT_TAG built."
docker images | grep -E "$(echo $OUT_TAG | cut -d: -f1)" || true
