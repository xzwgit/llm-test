#!/usr/bin/env bash
CNAME="mimo-v26-flash-vllm"
docker rm -f "$CNAME" 2>/dev/null && echo "已停止 $CNAME" || echo "无运行中的 $CNAME"
