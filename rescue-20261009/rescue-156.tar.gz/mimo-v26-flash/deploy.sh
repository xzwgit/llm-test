#!/usr/bin/env bash
# 部署 MiMo-V2.6-Flash-RL (8x RTX PRO 6000) via vLLM, 模型来自 ModelScope
# 镜像 ENTRYPOINT 已是 "vllm serve", docker run 末尾只跟参数
set -e
MODEL="XiaomiMiMo/MiMo-V2.6-Flash-RL"
IMAGE="vllm/vllm-openai:mimov25-cu129"
HOST_PORT=8000
CONTAINER_NAME="mimo-v26-flash-vllm"
MS_CACHE="/root/.cache/modelscope"

if ! docker image inspect "$IMAGE" >/dev/null 2>&1; then
  echo "拉取镜像 $IMAGE ..."
  docker pull "$IMAGE"
fi
docker rm -f "$CONTAINER_NAME" 2>/dev/null || true

docker run -d --name "$CONTAINER_NAME" \
  --gpus all --ipc=host --shm-size=32g \
  -p ${HOST_PORT}:8000 \
  -e VLLM_USE_MODELSCOPE=True \
  -e MODELSCOPE_CACHE="${MS_CACHE}" \
  -e PYTHONUNBUFFERED=1 \
  -v "${MS_CACHE}:${MS_CACHE}" \
  "$IMAGE" \
  "$MODEL" \
  --tensor-parallel-size 8 \
  --trust-remote-code \
  --gpu-memory-utilization 0.85 \
  --max-model-len 131072 \
  --reasoning-parser mimo \
  --tool-call-parser mimo \
  --enable-auto-tool-choice \
  --generation-config vllm \
  --served-model-name mimo-v2.6-flash-rl

echo "容器 $CONTAINER_NAME 已启动, 端口 $HOST_PORT"
